import { SignJWT, importPKCS8 } from "jose";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const teamId = process.env.APPLE_TEAM_ID;
    const keyId = process.env.APPLE_KEY_ID;
    const privateKeyPath = process.env.APPLE_PRIVATE_KEY_PATH;

    if (!teamId || !keyId || !privateKeyPath) {
      return NextResponse.json(
        {
          error:
            "Missing APPLE_TEAM_ID, APPLE_KEY_ID, or APPLE_PRIVATE_KEY_PATH.",
        },
        { status: 500 }
      );
    }

    const fullKeyPath = path.resolve(process.cwd(), privateKeyPath);
    const privateKeyText = await readFile(fullKeyPath, "utf8");

    const privateKey = await importPKCS8(privateKeyText, "ES256");

    const now = Math.floor(Date.now() / 1000);
    const expiration = now + 60 * 60 * 24 * 30;

    const developerToken = await new SignJWT({})
      .setProtectedHeader({
        alg: "ES256",
        kid: keyId,
      })
      .setIssuer(teamId)
      .setIssuedAt(now)
      .setExpirationTime(expiration)
      .sign(privateKey);

    return NextResponse.json(
      {
        developerToken,
        expiresAt: expiration,
      },
      {
        headers: {
          "Cache-Control": "no-store",
        },
      }
    );
  } catch (error) {
    console.error("Apple Music token error:", error);

    return NextResponse.json(
      {
        error: "Unable to generate the Apple Music developer token.",
      },
      { status: 500 }
    );
  }
}
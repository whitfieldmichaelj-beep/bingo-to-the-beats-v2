"use client";

import Image from "next/image";
import Link from "next/link";
import Script from "next/script";
import { useEffect, useState } from "react";

type AppleArtwork = {
  url?: string;
  width?: number;
  height?: number;
};

type ApplePlaylistAttributes = {
  name?: string;
  description?: {
    standard?: string;
    short?: string;
  };
  artwork?: AppleArtwork;
};

type ApplePlaylist = {
  id: string;
  type: string;
  href?: string;
  attributes?: ApplePlaylistAttributes;
};

type ApplePlaylistResponse = {
  data?: ApplePlaylist[];
  errors?: Array<{
    title?: string;
    detail?: string;
  }>;
};

type MusicKitInstance = {
  authorize: () => Promise<string>;
  unauthorize: () => Promise<void>;
  isAuthorized?: boolean;
  api: {
    music: (
      path: string,
      parameters?: Record<string, unknown>
    ) => Promise<ApplePlaylistResponse>;
  };
};

declare global {
  interface Window {
    MusicKit?: {
      configure: (configuration: {
        developerToken: string;
        app: {
          name: string;
          build: string;
        };
      }) => void | Promise<void>;

      getInstance: () => MusicKitInstance;
    };
  }
}

type ConnectionState =
  | "loading"
  | "ready"
  | "connecting"
  | "loading-playlists"
  | "connected"
  | "error";

export default function AppleMusicConnectionPage() {
  const [scriptReady, setScriptReady] = useState(false);
  const [status, setStatus] =
    useState<ConnectionState>("loading");
  const [playlists, setPlaylists] = useState<ApplePlaylist[]>([]);
  const [message, setMessage] = useState(
    "Preparing Apple Music..."
  );

  useEffect(() => {
    if (!scriptReady || !window.MusicKit) {
      return;
    }

    let cancelled = false;

    async function configureAppleMusic() {
      try {
        setStatus("loading");
        setMessage("Preparing Apple Music...");

        const response = await fetch("/api/apple-music/token", {
          method: "GET",
          cache: "no-store",
        });

        const data = (await response.json()) as {
          developerToken?: string;
          error?: string;
        };

        if (!response.ok || !data.developerToken) {
          throw new Error(
            data.error ||
              "Unable to generate the Apple Music developer token."
          );
        }

        const musicKit = window.MusicKit;

        if (!musicKit) {
          throw new Error(
            "The Apple Music connection library is unavailable."
          );
        }

        await musicKit.configure({
          developerToken: data.developerToken,
          app: {
            name: "Bingo to the Beats",
            build: "2.0.0",
          },
        });

        if (!cancelled) {
          setStatus("ready");
          setMessage(
            "Apple Music is ready. Click below to connect your account."
          );
        }
      } catch (error) {
        console.error("Apple Music configuration error:", error);

        if (!cancelled) {
          setStatus("error");
          setMessage(
            error instanceof Error
              ? error.message
              : "Unable to prepare Apple Music."
          );
        }
      }
    }

    void configureAppleMusic();

    return () => {
      cancelled = true;
    };
  }, [scriptReady]);

  function formatArtworkUrl(
    artwork?: AppleArtwork,
    width = 600,
    height = 600
  ) {
    if (!artwork?.url) {
      return "";
    }

    return artwork.url
      .replace("{w}", String(width))
      .replace("{h}", String(height));
  }

  async function loadPlaylists(music: MusicKitInstance) {
    setStatus("loading-playlists");
    setMessage("Loading your Apple Music playlists...");

    const response = await music.api.music(
      "/v1/me/library/playlists",
      {
        limit: 100,
      }
    );

    if (response.errors?.length) {
      const firstError = response.errors[0];

      throw new Error(
        firstError.detail ||
          firstError.title ||
          "Unable to load Apple Music playlists."
      );
    }

    const items = Array.isArray(response.data)
      ? response.data
      : [];

    setPlaylists(items);
    setStatus("connected");

    setMessage(
      items.length > 0
        ? `${items.length} Apple Music playlist${
            items.length === 1 ? "" : "s"
          } loaded.`
        : "Apple Music connected, but no playlists were found."
    );
  }

  async function connectAppleMusic() {
    console.log("Apple button clicked. Current status:", status);

    if (status !== "ready") {
      return;
    }

    const musicKit = window.MusicKit;

    if (!musicKit) {
      setStatus("error");
      setMessage("Apple Music did not load correctly.");
      return;
    }

    try {
      setStatus("connecting");
      setMessage("Waiting for Apple Music authorization...");

      const music = musicKit.getInstance();

      console.log("MusicKit instance created:", music);
      console.log("Starting Apple authorization...");

      const musicUserToken = await music.authorize();

      console.log(
        "Apple authorization completed:",
        Boolean(musicUserToken)
      );

      if (!musicUserToken) {
        throw new Error(
          "Apple Music did not return an authorization token."
        );
      }

      await loadPlaylists(music);
    } catch (error) {
      console.error("Apple Music authorization error:", error);

      setStatus("error");
      setMessage(
        error instanceof Error
          ? error.message
          : "Unable to authorize Apple Music."
      );
    }
  }

  async function disconnectAppleMusic() {
    try {
      const music = window.MusicKit?.getInstance();

      if (music) {
        await music.unauthorize();
      }

      setPlaylists([]);
      setStatus("ready");
      setMessage(
        "Apple Music is ready. Click below to connect your account."
      );
    } catch (error) {
      console.error("Apple Music disconnect error:", error);

      setStatus("error");
      setMessage("Unable to disconnect Apple Music.");
    }
  }

  const buttonDisabled =
    status === "loading" ||
    status === "connecting" ||
    status === "loading-playlists";

  return (
    <>
      <Script
        src="https://js-cdn.music.apple.com/musickit/v3/musickit.js"
        strategy="afterInteractive"
        onLoad={() => {
          setScriptReady(true);
        }}
        onError={() => {
          setStatus("error");
          setMessage(
            "The Apple Music connection library could not be loaded."
          );
        }}
      />

      <main
        style={{
          minHeight: "100vh",
          padding: "72px 24px 100px",
          background:
            "radial-gradient(circle at top, #4c0519 0%, #111827 44%, #030712 100%)",
          color: "white",
        }}
      >
        <section
          style={{
            width: "min(100%, 1100px)",
            margin: "0 auto",
          }}
        >
          <div style={{ textAlign: "center" }}>
            <Link
              href="/music"
              style={{
                display: "inline-block",
                marginBottom: "26px",
                color: "#fda4af",
                textDecoration: "none",
                fontWeight: 800,
              }}
            >
              ← Back to Music Providers
            </Link>

            <div
              style={{
                display: "flex",
                justifyContent: "center",
                marginTop: "10px",
                marginBottom: "28px",
              }}
            >
              <Image
                src="/logo.png"
                alt="Bingo to the Beats"
                width={210}
                height={210}
                priority
                style={{
                  width: "190px",
                  height: "auto",
                }}
              />
            </div>

            <p
              style={{
                margin: "24px 0 0",
                color: "#fb7185",
                fontSize: "14px",
                fontWeight: 900,
                letterSpacing: "0.14em",
                textTransform: "uppercase",
              }}
            >
              Apple Music
            </p>

            <h1
              style={{
                margin: "14px 0 0",
                fontSize: "clamp(42px, 7vw, 70px)",
                lineHeight: 1,
                letterSpacing: "-0.04em",
              }}
            >
              Connect your music library
            </h1>

            <p
              style={{
                maxWidth: "650px",
                margin: "24px auto 0",
                color: "#d1d5db",
                fontSize: "19px",
                lineHeight: 1.7,
              }}
            >
              Sign in with Apple Music to browse your playlists and
              select music for your Bingo to the Beats game.
            </p>
          </div>

          <section
            style={{
              width: "min(100%, 760px)",
              margin: "42px auto 0",
              padding: "36px",
              borderRadius: "24px",
              background: "rgba(15, 23, 42, 0.94)",
              border: "1px solid rgba(251, 113, 133, 0.38)",
              boxShadow:
                "0 24px 70px rgba(76, 5, 25, 0.32)",
              textAlign: "center",
            }}
          >
            <div
              style={{
                width: "82px",
                height: "82px",
                display: "grid",
                placeItems: "center",
                margin: "0 auto",
                borderRadius: "22px",
                background:
                  "linear-gradient(145deg, #fb7185, #e11d48)",
                fontSize: "42px",
              }}
            >
              ♪
            </div>

            <h2
              style={{
                margin: "24px 0 0",
                fontSize: "30px",
              }}
            >
              Apple Music Connection
            </h2>

            <p
              style={{
                margin: "14px auto 0",
                color:
                  status === "error"
                    ? "#fda4af"
                    : status === "connected"
                      ? "#bef264"
                      : "#cbd5e1",
                lineHeight: 1.7,
              }}
            >
              {message}
            </p>

            {status !== "connected" ? (
              <button
                type="button"
                onClick={connectAppleMusic}
                disabled={buttonDisabled || status === "error"}
                style={{
                  width: "100%",
                  marginTop: "28px",
                  padding: "16px 24px",
                  border: 0,
                  borderRadius: "999px",
                  background: "#fa2d48",
                  color: "white",
                  fontSize: "17px",
                  fontWeight: 900,
                  cursor:
                    buttonDisabled || status === "error"
                      ? "default"
                      : "pointer",
                  opacity:
                    buttonDisabled || status === "error"
                      ? 0.65
                      : 1,
                }}
              >
                {status === "loading"
                  ? "Preparing Apple Music..."
                  : status === "connecting"
                    ? "Authorizing..."
                    : status === "loading-playlists"
                      ? "Loading Playlists..."
                      : status === "error"
                        ? "Apple Music Error"
                        : "Connect Apple Music"}
              </button>
            ) : (
              <button
                type="button"
                onClick={disconnectAppleMusic}
                style={{
                  width: "100%",
                  marginTop: "28px",
                  padding: "16px 24px",
                  border:
                    "1px solid rgba(255,255,255,0.18)",
                  borderRadius: "999px",
                  background: "rgba(255,255,255,0.08)",
                  color: "white",
                  fontSize: "17px",
                  fontWeight: 900,
                  cursor: "pointer",
                }}
              >
                Disconnect Apple Music
              </button>
            )}
          </section>

          {status === "connected" && playlists.length > 0 && (
            <section style={{ marginTop: "42px" }}>
              <h2
                style={{
                  margin: 0,
                  fontSize: "32px",
                  textAlign: "center",
                }}
              >
                Choose an Apple Music Playlist
              </h2>

              <div
                style={{
                  display: "grid",
                  gridTemplateColumns:
                    "repeat(auto-fit, minmax(240px, 1fr))",
                  gap: "24px",
                  marginTop: "28px",
                }}
              >
                {playlists.map((playlist) => {
                  const name =
                    playlist.attributes?.name ||
                    "Untitled Playlist";

                  const description =
                    playlist.attributes?.description?.standard ||
                    playlist.attributes?.description?.short ||
                    "";

                  const artworkUrl = formatArtworkUrl(
                    playlist.attributes?.artwork
                  );

                  return (
                    <Link
                      key={playlist.id}
                      href={`/host/${encodeURIComponent(
                        playlist.id
                      )}?source=apple&name=${encodeURIComponent(
                        name
                      )}`}
                      style={{
                        display: "block",
                        overflow: "hidden",
                        borderRadius: "22px",
                        background: "rgba(15,23,42,0.94)",
                        border:
                          "1px solid rgba(255,255,255,0.1)",
                        color: "white",
                        textDecoration: "none",
                      }}
                    >
                      <div
                        style={{
                          aspectRatio: "1 / 1",
                          background:
                            "linear-gradient(145deg, #881337, #111827)",
                          overflow: "hidden",
                        }}
                      >
                        {artworkUrl ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img
                            src={artworkUrl}
                            alt={`${name} artwork`}
                            style={{
                              width: "100%",
                              height: "100%",
                              objectFit: "cover",
                            }}
                          />
                        ) : (
                          <div
                            style={{
                              width: "100%",
                              height: "100%",
                              display: "grid",
                              placeItems: "center",
                              fontSize: "64px",
                              color: "#fda4af",
                            }}
                          >
                            ♪
                          </div>
                        )}
                      </div>

                      <div style={{ padding: "20px" }}>
                        <h3
                          style={{
                            margin: 0,
                            fontSize: "21px",
                          }}
                        >
                          {name}
                        </h3>

                        {description && (
                          <p
                            style={{
                              margin: "10px 0 0",
                              color: "#cbd5e1",
                              fontSize: "14px",
                              lineHeight: 1.6,
                            }}
                          >
                            {description}
                          </p>
                        )}

                        <p
                          style={{
                            margin: "18px 0 0",
                            color: "#fda4af",
                            fontWeight: 900,
                          }}
                        >
                          Select Playlist →
                        </p>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </section>
          )}
        </section>
      </main>
    </>
  );
}
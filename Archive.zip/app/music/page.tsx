"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

type SpotifyStatus =
  | "checking"
  | "connected"
  | "disconnected"
  | "error";

type MusicSourceCardProps = {
  title: string;
  description: string;
  status: string;
  statusStyle: string;
  icon: string;
  children?: React.ReactNode;
};

function MusicSourceCard({
  title,
  description,
  status,
  statusStyle,
  icon,
  children,
}: MusicSourceCardProps) {
  return (
    <section className="group relative overflow-hidden rounded-3xl border border-white/10 bg-white/[0.06] p-6 shadow-2xl backdrop-blur-xl transition duration-300 hover:-translate-y-1 hover:border-purple-400/40 hover:bg-white/[0.09]">
      <div className="absolute -right-20 -top-20 h-48 w-48 rounded-full bg-purple-500/10 blur-3xl transition group-hover:bg-purple-500/20" />

      <div className="relative">
        <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-start">
          <div className="flex items-start gap-4">
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border border-white/10 bg-black/30 text-3xl shadow-lg">
              {icon}
            </div>

            <div>
              <h2 className="text-2xl font-black text-white">
                {title}
              </h2>

              <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-300">
                {description}
              </p>
            </div>
          </div>

          <span
            className={`w-fit rounded-full border px-3 py-1.5 text-xs font-bold ${statusStyle}`}
          >
            {status}
          </span>
        </div>

        {children && (
          <div className="mt-6 flex flex-wrap gap-3">
            {children}
          </div>
        )}
      </div>
    </section>
  );
}

export default function MusicPage() {
  const [spotifyStatus, setSpotifyStatus] =
    useState<SpotifyStatus>("checking");

  useEffect(() => {
    async function checkSpotify() {
      try {
        const response = await fetch("/api/spotify/player", {
          method: "GET",
          cache: "no-store",
        });

        const data = await response.json();

        setSpotifyStatus(
          data.connected === true
            ? "connected"
            : "disconnected"
        );
      } catch (error) {
        console.error(
          "Spotify connection check failed:",
          error
        );

        setSpotifyStatus("error");
      }
    }

    checkSpotify();
  }, []);

  function spotifyBadge() {
    switch (spotifyStatus) {
      case "checking":
        return {
          label: "Checking",
          style:
            "border-yellow-300/30 bg-yellow-400/10 text-yellow-200",
        };

      case "connected":
        return {
          label: "Connected",
          style:
            "border-green-300/30 bg-green-400/10 text-green-200",
        };

      case "error":
        return {
          label: "Connection Error",
          style:
            "border-red-300/30 bg-red-400/10 text-red-200",
        };

      default:
        return {
          label: "Not Connected",
          style:
            "border-slate-300/20 bg-slate-400/10 text-slate-200",
        };
    }
  }

  const spotify = spotifyBadge();

  return (
    <main className="relative min-h-screen overflow-hidden bg-[#070713] text-white">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-[-120px] top-20 h-96 w-96 rounded-full bg-purple-700/30 blur-[120px]" />
        <div className="absolute right-[-120px] top-40 h-96 w-96 rounded-full bg-pink-600/20 blur-[130px]" />
        <div className="absolute bottom-[-180px] left-1/3 h-[500px] w-[500px] rounded-full bg-blue-700/20 blur-[150px]" />
      </div>

      <div className="relative mx-auto max-w-6xl px-5 py-12 sm:px-8">
        <Link
          href="/dashboard"
          className="inline-flex items-center gap-2 text-sm font-bold text-purple-300 transition hover:text-white"
        >
          <span>←</span>
          Back to Dashboard
        </Link>

        <div className="mt-8 rounded-3xl border border-white/10 bg-gradient-to-br from-purple-950/80 via-[#111126] to-pink-950/50 p-8 shadow-2xl backdrop-blur-xl sm:p-10">
          <div className="max-w-3xl">
            <span className="inline-flex rounded-full border border-purple-300/20 bg-purple-400/10 px-4 py-2 text-xs font-black uppercase tracking-[0.22em] text-purple-200">
              Bingo to the Beats
            </span>

            <h1 className="mt-5 text-4xl font-black tracking-tight sm:text-5xl">
              Music Sources
            </h1>

            <p className="mt-4 text-base leading-7 text-slate-300 sm:text-lg">
              Connect your favorite music platforms and choose
              the source used to create and run your musical
              bingo games.
            </p>
          </div>
        </div>

        <div className="mt-8 grid gap-6">
          <MusicSourceCard
            title="Spotify"
            description="Import your Spotify playlists, monitor current playback, and prepare songs for live Bingo to the Beats games."
            status={spotify.label}
            statusStyle={spotify.style}
            icon="●"
          >
            <Link
              href="/api/spotify/login"
              className="rounded-xl bg-[#1DB954] px-5 py-3 text-sm font-black text-black shadow-lg transition hover:scale-[1.02] hover:bg-[#25d366]"
            >
              Connect Spotify
            </Link>

            <Link
              href="/spotify"
              className="rounded-xl border border-white/15 bg-white/10 px-5 py-3 text-sm font-black text-white transition hover:bg-white/15"
            >
              View Playlists
            </Link>
          </MusicSourceCard>

          <MusicSourceCard
            title="Apple Music"
            description="Connect Apple Music and import playlists after your Apple Music developer credentials are configured."
            status="Setup Required"
            statusStyle="border-yellow-300/30 bg-yellow-400/10 text-yellow-200"
            icon=""
          >
            <button
              type="button"
              disabled
              className="cursor-not-allowed rounded-xl border border-white/10 bg-white/10 px-5 py-3 text-sm font-black text-slate-400"
            >
              Connect Apple Music
            </button>
          </MusicSourceCard>

          <MusicSourceCard
            title="TIDAL"
            description="TIDAL playlist support will be added after Spotify and Apple Music are fully configured."
            status="Coming Soon"
            statusStyle="border-purple-300/30 bg-purple-400/10 text-purple-200"
            icon="◆"
          />

          <MusicSourceCard
            title="Serato"
            description="Import an exported Serato CSV playlist and use those tracks to generate musical bingo cards."
            status="Available"
            statusStyle="border-blue-300/30 bg-blue-400/10 text-blue-200"
            icon="♫"
          >
            <Link
              href="/serato"
              className="rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 px-5 py-3 text-sm font-black text-white shadow-lg transition hover:scale-[1.02] hover:from-blue-500 hover:to-purple-500"
            >
              Import Serato Playlist
            </Link>
          </MusicSourceCard>
        </div>
      </div>
    </main>
  );
}